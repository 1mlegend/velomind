import { Suspense, lazy } from "react";

const Spline = lazy(() => import("@splinetool/react-spline"));

interface SplineHeroProps {
  url: string;
  className?: string;
}

const SplineHero = ({ url, className = "" }: SplineHeroProps) => {
  return (
    <Suspense fallback={<div className="w-full h-full" />}>
      <Spline
        scene={url}
        style={{ width: "100%", height: "100%" }}
        className={className}
      />
    </Suspense>
  );
};

export default SplineHero;
